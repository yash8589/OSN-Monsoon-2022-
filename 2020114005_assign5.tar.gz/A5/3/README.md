# Report on Question 3

- In this question, we use networking to connect the client and server side of the code. We have used threads, semaphores, and mutex locks to do it
- We use the Belmond Ford algorithm to create the shortest path between the source and destination. We use the mutex locks to ensure that the shortest path is calculated correctly.
- We use the semaphores to ensure that the client and server are not accessing the same resource at the same time.
- We use the threads to ensure that the client and server are running simultaneously.
