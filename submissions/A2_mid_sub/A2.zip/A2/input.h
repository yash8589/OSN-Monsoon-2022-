#ifndef __INPUT_H
#define __INPUT_H

char *get_input();

#endif
