#ifndef __PARSE_H
#define __PARSE_H

char *removeSpacesFromStr(char *string);
long long parse(char *input, long long argc, char *argv[1000]);
char *removeSpacesFromCommand(char *string);

#endif
