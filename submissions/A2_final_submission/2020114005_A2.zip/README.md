# OSN ASSIGNMENT - 1

> Making a shell using C

## How to Use:

> `make`

> `./shell`

## Commands implemented
- cd
- pwd
- ls
- echo
- other system calls like sleep, gedit, etc
- discover
- pinfo

