#ifndef __INPUT_H
#define __INPUT_H

char *get_input();
void printGreen();
void printBlue();
void printCyan();
void resetColor();
void printYellow();

#endif
